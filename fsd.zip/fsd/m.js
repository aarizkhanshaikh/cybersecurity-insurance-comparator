const express = require('express');
const app = express();
const path = require('path');
const port = 3000;
const fs = require('fs');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.set('view engine', 'ejs');

app.get('/contact', (req, res) => {
    res.sendFile('./data_files/contact.html', { root: __dirname });
})

app.post('/submit-contact', (req, res) => {

    const { name, email, subject, message } = req.body;
    const data = `Name: ${name}\nEmail: ${email}\nSubject: ${subject}\nMessage: ${message}\n\n`

    fs.appendFile('data.txt', data, (err) => {

        if (err) {
            console.log("error in file...");
        }

        res.send("Your details have been submitted successfully");
    })
})

app.get('/form', function (req, res) {
    res.sendFile(path.join(__dirname, 'form.html'));
})

app.post('/form', (req, res) => {

    console.log(req.body);
    const { fname, email, industry, size, revenue, scale, insurance } = req.body;
    const data = `Name: ${fname}\nEmail: ${email}\nIndustry: ${industry}\nSize: ${size}\nRevenue: ${revenue}\nScale: ${scale}\nInsurance Type: ${insurance}\n\n`;

    fs.appendFile('./data_files/form_data.txt', data, (err) => {

        if (err) {
            console.log("error in file...");
        }
    })

    // Consultation Only logic
    if (req.body.insurance == "Consultation Only") {
        res.render('./insurances/consultation'); // Render consultation page
    } 
    
    else {
        // Handling cases other than consultation options...
        if (req.body.size == '10-100' && req.body.revenue <= 3 && req.body.scale == '1-3 (Low)') {
            if (req.body.insurance == "Software Only") {
                res.render('./insurances/software'); // Render software insurance page
            } 
            else if (req.body.insurance == "Hardware Only") {
                res.render('./insurances/hardware'); // Render hardware insurance page
            } 
            else if (req.body.insurance == "Software and Hardware") {
                res.render('./insurances/software_hardware'); // Render software and hardware insurance page
            }
        } 
        
        else if (req.body.size == '100-10,000' && req.body.revenue <= 10 && req.body.scale == '4-7 (Medium)') {
            if (req.body.insurance == "Software Only") {
                res.render('./insurances/software_medium'); // Render medium scale software insurance page
            } 
            else if (req.body.insurance == "Hardware Only") {
                res.render('./insurances/hardware_medium'); // Render medium scale hardware insurance page
            } 
            else if (req.body.insurance == "Software and Hardware") {
                res.render('./insurances/software_hardware_medium'); // Render medium scale software and hardware insurance page
            }
        } 
        
        else if (req.body.size == '10,000+' && req.body.revenue > 10 && req.body.scale == '8-10 (High)') {
            if (req.body.insurance == "Software Only") {
                res.render('./insurances/software_high'); // Render high scale software insurance page
            } 
            else if (req.body.insurance == "Hardware Only") {
                res.render('./insurances/hardware_high'); // Render high scale hardware insurance page
            } 
            else if (req.body.insurance == "Software and Hardware") {
                res.render('./insurances/software_hardware_high'); // Render high scale software and hardware insurance page
            }
        } 
        
        else {
            // Handle other cases or default response
            res.render('./insurances/default'); // Render a default page or error page
        }
    }
});

app.listen(port, function () {
    console.log("server running...");
})